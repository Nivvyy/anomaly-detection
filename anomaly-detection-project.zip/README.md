# Anomaly Detection for Server Security

This project uses an **Isolation Forest** model to detect anomalies in server log files.

## Features

- Data preprocessing from raw server logs
- Isolation Forest-based anomaly detection
- Modular and easy-to-extend structure

## Usage

1. Clone this repo:
    ```bash
    git clone https://github.com/yourusername/anomaly-detection.git
    cd anomaly-detection
    ```

2. Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```

3. Train the model:
    ```bash
    python src/train_model.py
    ```

4. Detect anomalies:
    ```bash
    python src/detect_anomalies.py
    ```

## Project Structure

- `data/`: Sample server logs
- `src/`: Scripts for preprocessing, training, and detection
- `model/`: Contains saved model after training

## Author

Your Name
