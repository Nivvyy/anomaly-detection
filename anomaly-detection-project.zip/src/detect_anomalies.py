import joblib
from preprocess import preprocess_logs

def detect():
    model = joblib.load('../model/isolation_forest.pkl')
    df = preprocess_logs('../data/sample_logs.csv')
    preds = model.predict(df)
    df['anomaly'] = preds
    print(df)

if __name__ == "__main__":
    detect()
