import pandas as pd

def preprocess_logs(file_path):
    df = pd.read_csv(file_path)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['hour'] = df['timestamp'].dt.hour
    df['is_error'] = df['status'].apply(lambda x: 1 if x >= 400 else 0)
    df = df.drop(columns=['timestamp', 'url', 'method'])
    df = pd.get_dummies(df, columns=['ip'], drop_first=True)
    return df
