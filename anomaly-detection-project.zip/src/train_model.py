from sklearn.ensemble import IsolationForest
import joblib
from preprocess import preprocess_logs

def train_and_save_model():
    df = preprocess_logs('../data/sample_logs.csv')
    model = IsolationForest(n_estimators=100, contamination=0.1, random_state=42)
    model.fit(df)
    joblib.dump(model, '../model/isolation_forest.pkl')
    print("Model saved at ../model/isolation_forest.pkl")

if __name__ == "__main__":
    train_and_save_model()
